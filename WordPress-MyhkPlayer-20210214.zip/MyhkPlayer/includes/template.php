<?php
function player_jq() {
	if(get_option('jq')=='open'){
		echo '<script src="//lib.baomitu.com/jquery/3.5.1/jquery.min.js"></script>'."\n";
	}
}
function player_js(){
	if(get_option('mb')=='open'){
		echo '<script id="myhk" src="https://myhkw.cn/api/player/' . get_option('id') . '" key="' . get_option('id') . '" m="1"></script>'."\n";
	}else{
		echo '<script id="myhk" src="https://myhkw.cn/api/player/' . get_option('id') . '" key="' . get_option('id') . '"></script>'."\n";
	}
}
?>